from django.shortcuts import render, redirect
from . import views
from .models import PostModel
# Create your views here.

def home(request):
    posts_list = sorted(list(PostModel.objects.all()), key=lambda p: p.created_at)
    return render(request,'index.html',{'posts':posts_list} )


def newpost(request):
    if request.method == 'POST':
        title = request.POST['title']
        body =request.POST['body']
        
        newpost = PostModel.objects.create(title=title,body=body)
        newpost.save()
        return redirect('/')
    return render(request,'newpost.html')



def posts(request, pk):
    post = PostModel.objects.get(id = pk)
    return render(request, 'post.html', {'post':post})